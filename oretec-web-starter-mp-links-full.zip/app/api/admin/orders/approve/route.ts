import { NextRequest, NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  try {
    const { orderId } = await req.json()
    if (!orderId) return NextResponse.json({ error: 'Falta orderId' }, { status: 400 })
    const supabase = supabaseServer()

    const { data: order, error: oErr } = await supabase.from('orders').select('*').eq('id', orderId).single()
    if (oErr || !order) return NextResponse.json({ error: 'Orden no encontrada' }, { status: 404 })

    await supabase.from('orders').update({ status: 'paid' }).eq('id', orderId)
    await supabase.from('enrollments')
      .insert({ user_id: order.user_id, course_id: order.course_id, paid: true })
      .select().single()

    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Error interno' }, { status: 500 })
  }
}
