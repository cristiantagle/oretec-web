import { NextRequest, NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  try {
    const { orderId, note } = await req.json()
    if (!orderId) return NextResponse.json({ error: 'Falta orderId' }, { status: 400 })
    const supabase = supabaseServer()

    const { error } = await supabase
      .from('orders')
      .update({ status: 'failed', payment_notes: note ?? 'Rechazada por admin' })
      .eq('id', orderId)

    if (error) return NextResponse.json({ error: 'No se pudo rechazar' }, { status: 400 })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Error interno' }, { status: 500 })
  }
}
