# OreTec Web Starter

Proyecto base Next.js + Supabase + MercadoPago Links.
